var nome;
var cognome;
var corso;
var addBtn;
var elencoHTML;
var errore;
var erroreElenco;
var elenco = [];
var cambia;

window.addEventListener('DOMContentLoaded', init);

function init() {
    nome = document.getElementById('nome');
    cognome = document.getElementById('cognome');
    corso = document.getElementById('corso');
    addBtn = document.getElementById('scrivi');
    elencoHTML = document.getElementById('elenco');
    errore = document.getElementById('errore');
    erroreElenco = document.getElementById('erroreElenco');
    printData();
    eventHandler();
}

// Funzione che stampa i dati del json
function printData() {
    fetch('http://localhost:3000/elenco')
        .then((response) => {
            return response.json();
        })
        .then((data) => {
            elenco = data;
            if(elenco.length > 0) {
                errore.innerHTML = '';
                elencoHTML.innerHTML = '';
                elenco.map(function (element) {
                    elencoHTML.innerHTML += `
                    <li class="text-light">
                        ${element.nome} ${element.cognome} - Corso: ${element.corso}
                        <div>
                            <button type="button" class="btn" onclick="modifica(${element.id})"><i class="bi bi-pen"></i></button>
                            <button type="button" class="btn" onclick="elimina(${element.id})"><i class="bi bi-x-circle"></i></button>
                        </div>
                    </li>`
                });
            } else {
                erroreElenco.innerHTML = 'Nessun elemento presente in elenco';
            }
        });
}

function eventHandler() {
    addBtn.addEventListener('click', function() {
        if(cambia) {
            editData(cambia);
        } else {
            controlla();
        }
    });
}

// Funzione che controlla se gli input sono compilati
function controlla() {
    if (nome.value != '' && cognome.value != '' && corso.value != '') {
        let data = {
            nome: nome.value,
            cognome: cognome.value,
            corso: corso.value,
        }
        addData(data);
    } else {
        errore.innerHTML = 'Attenzione! Compilare correttamente tutti i campi.';
        return;
    }
}

// Funzione che invia i dati degli input al json
async function addData(data) {
    let response = await fetch('http://localhost:3000/elenco', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json;charset=utf-8',
        },
        body: JSON.stringify(data),
    });
    clearForm();
}

// Funzione che modifica i dati
function modifica(numero) {
    fetch(`http://localhost:3000/elenco/${numero}`)
        .then((response) => {
            return response.json();
        })
        .then((data) => {
            nome.value = data.nome;
            cognome.value = data.cognome;
            corso.value = data.corso;
        });

    return cambia = numero;
}

// Funzione che dice al json di modificare i dati
function editData(numero) {
    if(nome.value != '' && cognome.value != '' && corso.value != '') {
        fetch(`http://localhost:3000/elenco/${numero}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json;charset=utf-8',
            },
            body: JSON.stringify({
                nome: nome.value,
                cognome: cognome.value,
                corso: corso.value
            }),
        });
    } else {
        errore.innerHTML = `In attesa della sostituzione.\n Compilare correttamente tutti i campi!`;
        return;
    }
}

// Funzione che elimina il record
function elimina(numero) {
    if (window.confirm('Sei sicuro? L\'operazione è irreversibile')) {
        return fetch(`http://localhost:3000/elenco/${numero}`, {
            method: 'DELETE',
        });
    }
}

// Funzione cancella form
function clearForm() {
    nome.value = '';
    cognome.value = '';
    corso.value = '';
}